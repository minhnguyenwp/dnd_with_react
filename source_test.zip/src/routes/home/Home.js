/**
 * React Starter Kit (https://www.reactstarterkit.com/)
 *
 * Copyright © 2014-present Kriasoft, LLC. All rights reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.txt file in the root directory of this source tree.
 */

import React from 'react';
import PropTypes from 'prop-types';
import Link from '../../components/Link';

// import libary
import { DragDropContext, Droppable } from 'react-beautiful-dnd';

// import sub-comp
import NewList from './components/NewList';
import PausedProfiles from './components/PausedProfiles';

// a little function to help us with reordering the result
const reorder = (list, startIndex, endIndex) => {
  const result = Array.from(list);
  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);
  console.log('result', result);
  return result;
};

class Home extends React.Component {
  static propTypes = {
    title: PropTypes.string,
  };

  constructor(props) {
    super(props);
    this.onDragEnd = this.onDragEnd.bind(this);
  }

  componentWillMount() {
    let arrNew = [
      {
        id: 1,
        title: 'Internations',
        desc: ''
      },
      {
        id: 2,
        title: 'Designer',
        desc: 'Freelancer, Female'
      },
      {
        id: 3,
        title: 'Product owner',
        desc: 'Startup, Corporate'
      }
    ];
    let arrPaused = [
      {
        id: 4,
        title: 'Designer',
        desc: 'Hyper Island, Female'
      },
      {
        id: 5,
        title: 'Surprise me',
        desc: '(An unexpected match is chosen)'
      },
      {
        id: 6,
        title: 'Growth hacker',
        desc: 'Startup, 25-35 years old'
      }
    ];

    // create list profile
    this.setState({
      arrNewProfiles: arrNew,
      arrPausedProfiles: arrPaused
    });
  }

  onDragEnd(result) {
    // dropped outside the list
    if (!result.destination) {
      return;
    }
    
    const arrNewProfiles = reorder(
      this.state.arrNewProfiles,
      result.source.index,
      result.destination.index
    );

    // this.setState({
    //   arrNewProfiles,
    // });
  }

  render() {
    const {arrNewProfiles, arrPausedProfiles} = this.state;
    return (
      <div className="profile_wrap">
          <div className="title_wrap">
            <h1 className="ttl">Match Profile</h1>
            <Link to={'/#'} className="addnew"><span>+</span></Link>
          </div>
          {/* END TITLE */}

          <DragDropContext onDragEnd={this.onDragEnd}>
            <Droppable droppableId="droppable">
              {(provided, snapshot) => (
                <div ref={provided.innerRef}>
                  {arrNewProfiles !== null && <NewList dataNews={arrNewProfiles}/>}
                  {/* END NEW LIST */}

                  {arrPausedProfiles !== null && <PausedProfiles dataProfiles={arrPausedProfiles}/>}
                  {/* END PAUSED PROFILES */}
                </div>
              )}
            </Droppable>
          </DragDropContext>
          
          

          <div className="button_wrap">
            <button type="button">Submit profiles</button>
          </div>         
          {/* END BUTTON SUBMIT */} 
      </div>
    );
  }
}

export default Home;
